#!/usr/bin/env python

"""Top-level script to invoke helloworld implementation."""

import sys
import helloworld.main

if __name__ == '__main__':
    sys.exit(helloworld.main.main())
